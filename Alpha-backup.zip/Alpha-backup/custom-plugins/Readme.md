<u>All custom-plugins are stored in this directory</u>
<br>
<br>
<b>Credits goes to their respectable creators.</b