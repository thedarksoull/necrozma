metronome data is kocated here.
